const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const db = new Database(process.env.DB_PATH || path.join(__dirname, '..', 'safety.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, phone TEXT,
  password_hash TEXT NOT NULL, home_area TEXT, emergency_contact TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')));
CREATE TABLE IF NOT EXISTS areas (
  name TEXT PRIMARY KEY, lat REAL NOT NULL, lon REAL NOT NULL, incident REAL, night_risk REAL, community REAL, infrastructure REAL,
  location_score REAL NOT NULL, theft REAL, night_safety REAL, road_safety REAL, women_safety REAL);
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT, report_id TEXT UNIQUE, area TEXT NOT NULL REFERENCES areas(name),
  issue_type TEXT NOT NULL, category TEXT NOT NULL, time_slot TEXT NOT NULL CHECK (time_slot IN ('morning','afternoon','night')),
  severity TEXT NOT NULL, description TEXT NOT NULL, report_time TEXT, days_ago INTEGER, latitude REAL, longitude REAL,
  source TEXT NOT NULL DEFAULT 'user', user_id INTEGER REFERENCES users(id), submitted_at TEXT, tz_offset_min INTEGER);
CREATE INDEX IF NOT EXISTS idx_reports_area_slot ON reports(area, time_slot);
CREATE TABLE IF NOT EXISTS bus_stops (
  stop_id TEXT PRIMARY KEY, name TEXT, area TEXT, lat REAL, lon REAL, shelter_type TEXT, shelter_condition TEXT,
  night_safety TEXT, night_severity TEXT, lighting TEXT, has_cctv INTEGER, source TEXT);
CREATE TABLE IF NOT EXISTS police_stations (
  id INTEGER PRIMARY KEY AUTOINCREMENT, station_id INTEGER, name TEXT, code TEXT, area TEXT, lat REAL, lon REAL, needs_verification INTEGER DEFAULT 0);
`);

// Loads /data/*.json into the database the first time (when the areas table is empty).
function seed() {
  if (db.prepare('SELECT COUNT(*) c FROM areas').get().c > 0) return false;
  const read = f => JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', f), 'utf8'));
  db.transaction(() => {
    const a = db.prepare('INSERT INTO areas VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
    for (const x of read('locations.json')) {
      const b = x.scoreBreakdown;
      a.run(x.locationName, x.latitude, x.longitude, x.incidentScore, x.nightRiskScore, x.communityScore, x.infrastructureScore,
        x.locationScore, b.theft, b.nightSafety, b.roadSafety, b.womenSafety);
    }
    const r = db.prepare(`INSERT INTO reports (report_id,area,issue_type,category,time_slot,severity,description,report_time,days_ago,latitude,longitude,source)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,'seed')`);
    for (const x of read('reports.json'))
      r.run(x.reportId, x.location, x.issueType, x.category, x.timeSlot, x.severity, x.description, x.reportTime, x.daysAgo, x.latitude, x.longitude);
    const b = db.prepare('INSERT INTO bus_stops VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
    for (const x of read('bus_stops.json'))
      b.run(x.stopId, x.stopName, x.location, x.latitude, x.longitude, x.shelterType, x.shelterCondition, x.nightSafety, x.nightSeverity,
        x.lighting, x.hasCCTV == null ? null : +x.hasCCTV, x.source);
    const p = db.prepare('INSERT INTO police_stations (station_id,name,code,area,lat,lon,needs_verification) VALUES (?,?,?,?,?,?,?)');
    for (const x of read('police_stations.json')) p.run(x.stationId, x.stationName, x.stationCode, x.location, x.latitude, x.longitude, x.needsVerification ? 1 : 0);
  })();
  return true;
}
module.exports = { db, seed };
