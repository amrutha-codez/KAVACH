# Safety backend, database and Community page

Node.js + Express + SQLite. No separate database server is needed.

## Run it
```bash
npm install
cp .env.example .env        # then set JWT_SECRET to a long random string
npm run seed                # optional: the server also seeds an empty database on first start
npm start                   # http://localhost:3000  ->  Community page: http://localhost:3000/community.html
npm test                    # scoring + time-of-day tests
npm run export              # writes data/reports.export.json (seed + user-submitted reports)
```
Geolocation needs HTTPS or `localhost`, so test on your laptop at `localhost`, or deploy behind HTTPS to test on a phone.

## Files
| File | Purpose |
|---|---|
| `server/scoring.js` | Score calculation, bands, time-of-day logic, distance and nearest-area |
| `server/db.js` | SQLite schema + seeding from `data/*.json` |
| `server/server.js` | REST API (auth, area scores, reports, search, rankings, map layers) |
| `server/seed.js`, `server/export.js` | Load the JSON datasets / export them again |
| `public/community.html` | Community page: report form, recent reports, search |
| `data/*.json` | locations, reports, police_stations, bus_stops (the datasets) |
| `docs/api-examples.json` | Request/response JSON for every endpoint |

## How a report flows
1. The phone sends its GPS position, its clock (`clientTime`) and its UTC offset (`tzOffsetMinutes`) with the category, severity and text.
2. The server finds the nearest area (rejects anything over 25 km away) and works out the time of day from the phone's clock: morning 5-12, afternoon 12-18, night 18-5.
3. The report is saved in the `reports` table under that area and time of day.
4. The score for that area and time of day is recalculated and returned (`score.before` to `score.after`).

## Score logic
- Base: morning = `locationScore` + 8; afternoon = `locationScore` + 14; night = `locationScore` - round(0.3 x `nightRiskScore`).
- Live adjustment from user reports in the last 30 days, per time of day: low -1, medium -2, high -3 (capped at -10); "Felt safe" +1 each (capped at +5).
- Bands: 65-100 Safe, 45-64 Medium, 0-44 Risky. Seed reports are already inside the base score, so only user reports adjust it.

## Endpoints
| Method | Path | Notes |
|---|---|---|
| POST | `/api/auth/register`, `/api/auth/login` | returns `{token, user}` (JWT, 7 days) |
| GET | `/api/auth/me` | needs `Authorization: Bearer <token>` |
| GET | `/api/areas/current?lat&lon&tz&at` | nearest area + scores for the phone's time of day + 3 nearby areas |
| GET | `/api/areas`, `/api/areas/:name` | all areas / one area (`?slot=` or `?tz&at`) |
| GET | `/api/rankings?slot&limit` | safest and least safe areas |
| GET | `/api/compare?areas=A,B,C` | metrics side by side |
| GET | `/api/search?q=` | matches area names and report text; scores include user reports |
| GET | `/api/reports?area&tz&at` | recent reports for the area at the phone's time of day |
| POST | `/api/reports` | login required, see `docs/api-examples.json` |
| GET | `/api/bus-stops/nearby`, `/api/police/nearby` | `?lat&lon&limit` |

## Before going live
Use a strong `JWT_SECRET`, serve over HTTPS, restrict CORS to your frontend's origin, and back up `safety.db`.
