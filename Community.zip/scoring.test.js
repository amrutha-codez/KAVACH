const assert = require('assert');
const S = require('../server/scoring');
const data = require('../data/locations.json');
const row = n => { const x = data.find(d => d.locationName === n); return { name: n, location_score: x.locationScore, night_risk: x.nightRiskScore, lat: x.latitude, lon: x.longitude }; };
const sc = n => S.SLOT_NAMES.map(s => S.baseScore(row(n), s));

// time of day (boundaries)
[[4,'night'],[5,'morning'],[11,'morning'],[12,'afternoon'],[17,'afternoon'],[18,'night'],[23,'night'],[0,'night']].forEach(([h, s]) => assert.strictEqual(S.slotForHour(h), s, `hour ${h}`));
// device offset: 2026-11-05T03:45Z is 09:15 in IST (+330) -> morning; the same instant in UTC is 03:45 -> night
assert.strictEqual(S.slotForInstant('2026-11-05T03:45:00Z', 330), 'morning');
assert.strictEqual(S.slotForInstant('2026-11-05T03:45:00Z', 0), 'night');
assert.strictEqual(S.localParts('2026-11-05T03:45:00Z', 330).time, '09:15');
// scores match the dashboard mockups
assert.deepStrictEqual(sc('Cubbon Park'), [76, 82, 56]);
assert.deepStrictEqual(sc('Koramangala'), [61, 67, 36]);
assert.deepStrictEqual(sc('CMRIT, AECS Layout'), [85, 91, 62]);
assert.deepStrictEqual(sc('Majestic'), [40, 46, 8]);
// bands
assert.deepStrictEqual([64, 65, 44, 45].map(S.bandFor), ['Medium', 'Safe', 'Risky', 'Medium']);
// live adjustment from user reports
assert.strictEqual(S.liveAdjustment([{ category: 'harassment', severity: 'high' }]), -3);
assert.strictEqual(S.liveAdjustment(Array(9).fill({ category: 'harassment', severity: 'high' })), -10);   // capped
assert.strictEqual(S.liveAdjustment(Array(9).fill({ category: 'felt_safe', severity: 'low' })), 5);      // capped
assert.strictEqual(S.scoreFor(row('Koramangala'), 'night', [{ category: 'harassment', severity: 'high' }]).score, 33);
// relative days
assert.strictEqual(S.daysAgoBetween('2026-11-04T20:00:00Z', '2026-11-05T03:45:00Z', 330), 0);   // both on 5 Nov in IST
assert.strictEqual(S.daysAgoLabel(1), 'yesterday');
// nearest area from phone GPS
const areas = data.map(d => ({ name: d.locationName, lat: d.latitude, lon: d.longitude }));
assert.strictEqual(S.nearestArea(areas, 12.9666, 77.7118).area.name, 'CMRIT, AECS Layout');
assert.strictEqual(S.nearestArea(areas, 28.6, 77.2), null);   // Delhi is outside coverage
console.log('All scoring tests passed');
