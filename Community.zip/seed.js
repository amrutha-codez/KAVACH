require('dotenv').config();
const { seed } = require('./db');
console.log(seed() ? 'Database seeded from /data/*.json' : 'Database already has data - nothing to do');
