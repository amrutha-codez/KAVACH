require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const { db, seed } = require('./db');
const S = require('./scoring');

seed();
const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 16) { console.error('Set JWT_SECRET (16+ characters) in .env'); process.exit(1); }

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 30 });
const reportLimiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 20 });
const bad = (res, msg, code = 400) => res.status(code).json({ error: msg });
const num = v => (v === undefined || v === '' || v === null ? NaN : Number(v));
const validCoords = (la, lo) => Number.isFinite(la) && Number.isFinite(lo) && Math.abs(la) <= 90 && Math.abs(lo) <= 180;
const tzOf = v => { const n = Number(v); return Number.isInteger(n) && Math.abs(n) <= 840 ? n : 330; };  // device offset in minutes; default IST
const allAreas = () => db.prepare('SELECT * FROM areas').all();
const CATEGORY = { poor_lighting: 'Poor lighting', harassment: 'Harassment', felt_unsafe: 'Felt unsafe', felt_safe: 'Felt safe' };

// ---------- helpers ----------
// Reports submitted by users in the last 30 days, grouped by time of day. These move the live score.
function recentUserReports(area, days = 30) {
  const rows = db.prepare(`SELECT category, severity, time_slot FROM reports WHERE area=? AND source='user' AND submitted_at >= ?`)
    .all(area, new Date(Date.now() - days * 864e5).toISOString());
  const by = { morning: [], afternoon: [], night: [] };
  rows.forEach(r => by[r.time_slot].push(r));
  return by;
}
function areaView(a, slot) {
  const scores = S.allSlotScores(a, recentUserReports(a.name));
  return { name: a.name, latitude: a.lat, longitude: a.lon, scores, current: scores[slot],
    metrics: { incidentRisk: a.incident, nightRisk: a.night_risk, community: a.community, infrastructure: a.infrastructure }, breakdown: S.breakdown(a) };
}
// Time of day comes from the DEVICE: `at` (device ISO time) + `tz` (device offset in minutes). Falls back to server time + tz.
function resolveSlot(q) {
  const tz = tzOf(q.tz);
  if (S.SLOT_NAMES.includes(q.slot)) return { slot: q.slot, tz };
  const at = q.at ? new Date(q.at) : new Date();
  return { slot: S.slotForInstant(Number.isNaN(at.getTime()) ? new Date() : at, tz), tz };
}
function reportView(r, viewerTz) {
  let time = r.report_time, daysAgo = r.days_ago;
  if (r.source === 'user') { time = S.localParts(r.submitted_at, r.tz_offset_min).time; daysAgo = S.daysAgoBetween(r.submitted_at, new Date(), viewerTz); }
  return { id: r.id, area: r.area, issueType: r.issue_type, category: r.category, severity: r.severity, description: r.description,
    timeSlot: r.time_slot, time, daysAgo, when: S.daysAgoLabel(daysAgo), source: r.source };
}
const userView = u => ({ id: u.id, name: u.name, email: u.email, phone: u.phone, homeArea: u.home_area, emergencyContact: u.emergency_contact });
const sign = u => jwt.sign({ sub: u.id }, SECRET, { expiresIn: '7d' });
function auth(req, res, next) {
  try { req.userId = jwt.verify((req.headers.authorization || '').replace(/^Bearer /, ''), SECRET).sub; next(); }
  catch { bad(res, 'Login required', 401); }
}

// ---------- auth ----------
app.post('/api/auth/register', authLimiter, (req, res) => {
  const { name, email, password, phone, homeArea, emergencyContact } = req.body || {};
  if (!name || !/^\S+@\S+\.\S+$/.test(email || '') || typeof password !== 'string' || password.length < 8)
    return bad(res, 'Name, a valid email and a password of 8+ characters are required');
  if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email.toLowerCase())) return bad(res, 'That email is already registered', 409);
  const id = db.prepare('INSERT INTO users (name,email,phone,password_hash,home_area,emergency_contact) VALUES (?,?,?,?,?,?)')
    .run(name.trim(), email.toLowerCase(), phone || null, bcrypt.hashSync(password, 10), homeArea || null, emergencyContact || null).lastInsertRowid;
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  res.status(201).json({ token: sign(u), user: userView(u) });
});
app.post('/api/auth/login', authLimiter, (req, res) => {
  const { email, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE email=?').get(String(email || '').toLowerCase());
  if (!u || !bcrypt.compareSync(String(password || ''), u.password_hash)) return bad(res, 'Wrong email or password', 401);
  res.json({ token: sign(u), user: userView(u) });
});
app.get('/api/auth/me', auth, (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.userId);
  u ? res.json(userView(u)) : bad(res, 'User not found', 404);
});

// ---------- area scores ----------
// GET /api/areas/current?lat=&lon=&tz=330&at=<device ISO time>  -> nearest area to the phone + score for the phone's time of day
app.get('/api/areas/current', (req, res) => {
  const la = num(req.query.lat), lo = num(req.query.lon);
  if (!validCoords(la, lo)) return bad(res, 'lat and lon are required');
  const { slot, tz } = resolveSlot(req.query), ranked = S.rankByDistance(allAreas(), la, lo);
  if (ranked[0].distanceKm > 25) return bad(res, 'You are outside the covered area', 422);
  res.json({ slot, tzOffsetMinutes: tz, distanceKm: +ranked[0].distanceKm.toFixed(2), area: areaView(ranked[0].area, slot),
    nearby: ranked.slice(1, 4).map(x => ({ name: x.area.name, distanceKm: +x.distanceKm.toFixed(1), ...areaView(x.area, slot).current })) });
});
app.get('/api/areas', (req, res) => {
  const { slot } = resolveSlot(req.query);
  res.json({ slot, areas: allAreas().map(a => { const v = areaView(a, slot); return { name: v.name, latitude: v.latitude, longitude: v.longitude, ...v.current }; }) });
});
app.get('/api/areas/:name', (req, res) => {
  const a = db.prepare('SELECT * FROM areas WHERE name=?').get(req.params.name);
  if (!a) return bad(res, 'Area not found', 404);
  const { slot } = resolveSlot(req.query);
  res.json({ slot, ...areaView(a, slot) });
});
app.get('/api/rankings', (req, res) => {
  const { slot } = resolveSlot(req.query), limit = Math.min(20, Number(req.query.limit) || 3);
  const rows = allAreas().map(a => ({ name: a.name, ...areaView(a, slot).current })).sort((x, y) => y.score - x.score || x.name.localeCompare(y.name));
  res.json({ slot, safest: rows.slice(0, limit), leastSafe: rows.slice(-limit).reverse() });
});
app.get('/api/compare', (req, res) => {
  const { slot } = resolveSlot(req.query);
  const rows = String(req.query.areas || '').split(',').slice(0, 3).map(n => db.prepare('SELECT * FROM areas WHERE name=?').get(n.trim())).filter(Boolean).map(a => areaView(a, slot));
  res.json({ slot, areas: rows.map(v => ({ name: v.name, ...v.current, ...v.metrics })) });
});
// SEARCH: matches area names AND the text of reports (landmarks like "5th Block"), and returns scores that include user reports.
app.get('/api/search', (req, res) => {
  const q = String(req.query.q || '').trim().replace(/[%_]/g, '');
  if (q.length < 2) return bad(res, 'q must be at least 2 characters');
  const { slot, tz } = resolveSlot(req.query), like = `%${q}%`;
  const names = db.prepare(`SELECT name FROM areas WHERE name LIKE ? UNION SELECT area FROM reports WHERE description LIKE ? LIMIT 10`).all(like, like).map(r => r.name);
  const results = names.map(n => {
    const a = db.prepare('SELECT * FROM areas WHERE name=?').get(n), v = areaView(a, slot);
    const c = db.prepare(`SELECT COUNT(*) total, COALESCE(SUM(source='user'),0) fromUsers FROM reports WHERE area=?`).get(n);
    const latest = db.prepare(`SELECT * FROM reports WHERE area=? AND time_slot=? ORDER BY (source='user') DESC, submitted_at DESC, days_ago ASC LIMIT 3`).all(n, slot);
    return { name: n, latitude: a.lat, longitude: a.lon, ...v.current, reportCount: c.total, userReportCount: c.fromUsers, latestReports: latest.map(r => reportView(r, tz)) };
  });
  res.json({ query: q, slot, results });
});

// ---------- reports ----------
// GET /api/reports?area=Cubbon Park&tz=330&at=...   -> recent reports for that area in the phone's time of day
app.get('/api/reports', (req, res) => {
  if (!req.query.area) return bad(res, 'area is required');
  const { slot, tz } = resolveSlot(req.query), limit = Math.min(50, Number(req.query.limit) || 10);
  const rows = db.prepare(`SELECT * FROM reports WHERE area=? AND time_slot=? ORDER BY (source='user') DESC, submitted_at DESC, days_ago ASC LIMIT ?`)
    .all(req.query.area, slot, limit);
  res.json({ area: req.query.area, slot, reports: rows.map(r => reportView(r, tz)) });
});
// POST /api/reports (login required): area + time of day are decided from the device's GPS and clock, then the score is recalculated.
app.post('/api/reports', auth, reportLimiter, (req, res) => {
  const b = req.body || {}, la = num(b.latitude), lo = num(b.longitude), at = new Date(b.clientTime), tz = tzOf(b.tzOffsetMinutes);
  if (!CATEGORY[b.category]) return bad(res, 'category must be one of: ' + Object.keys(CATEGORY).join(', '));
  if (!['low', 'medium', 'high'].includes(b.severity)) return bad(res, 'severity must be low, medium or high');
  const text = String(b.description || '').trim();
  if (text.length < 5 || text.length > 500) return bad(res, 'description must be 5-500 characters');
  if (!validCoords(la, lo)) return bad(res, 'latitude and longitude from the device are required');
  if (Number.isNaN(at.getTime()) || Math.abs(Date.now() - at.getTime()) > 10 * 60 * 1000) return bad(res, 'Device clock is more than 10 minutes off. Fix the phone time and retry');
  const near = S.nearestArea(allAreas(), la, lo);
  if (!near) return bad(res, 'Your location is outside the covered area', 422);
  const slot = S.slotForInstant(at, tz);                       // time-of-day category for this report
  const before = areaView(near.area, slot).current.score;
  const id = db.prepare(`INSERT INTO reports (area,issue_type,category,time_slot,severity,description,latitude,longitude,source,user_id,submitted_at,tz_offset_min)
      VALUES (?,?,?,?,?,?,?,?,'user',?,?,?)`).run(near.area.name, CATEGORY[b.category], b.category, slot, b.severity, text, la, lo, req.userId, at.toISOString(), tz).lastInsertRowid;
  const after = areaView(near.area, slot).current;             // score recalculated including this report
  res.status(201).json({ report: reportView(db.prepare('SELECT * FROM reports WHERE id=?').get(id), tz), area: near.area.name, timeSlot: slot,
    score: { before, after: after.score, band: after.band, severity: after.severity } });
});

// ---------- map layers ----------
const nearby = (table, cols) => (req, res) => {
  const la = num(req.query.lat), lo = num(req.query.lon);
  if (!validCoords(la, lo)) return bad(res, 'lat and lon are required');
  const rows = db.prepare(`SELECT ${cols} FROM ${table}`).all()
    .map(r => ({ ...r, distanceKm: +S.haversineKm(la, lo, r.lat, r.lon).toFixed(2) })).sort((x, y) => x.distanceKm - y.distanceKm).slice(0, Math.min(50, Number(req.query.limit) || 5));
  res.json({ results: rows });
};
app.get('/api/bus-stops/nearby', nearby('bus_stops', 'stop_id AS id, name, area, lat, lon, night_safety AS nightSafety, lighting, has_cctv AS hasCCTV'));
app.get('/api/police/nearby', nearby('police_stations', 'id, name, area, lat, lon, needs_verification AS needsVerification'));
app.get('/api/health', (_req, res) => res.json({ ok: true }));

app.listen(process.env.PORT || 3000, () => console.log(`Safety API running on http://localhost:${process.env.PORT || 3000}`));
