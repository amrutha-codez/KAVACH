// Score calculation + time-of-day logic. Pure functions, no database access.
const SLOTS = [
  { name: 'morning',   start: 5,  end: 12 },
  { name: 'afternoon', start: 12, end: 18 },
  { name: 'night',     start: 18, end: 5 }   // wraps past midnight
];
const SLOT_NAMES = SLOTS.map(s => s.name);
const clamp = n => Math.max(0, Math.min(100, n));
const roundHalfUp = x => Math.floor(x + 0.5);

// --- Time of day -----------------------------------------------------------
function slotForHour(h) {
  if (h >= 5 && h < 12) return 'morning';
  if (h >= 12 && h < 18) return 'afternoon';
  return 'night';
}
// Wall-clock parts for an instant, given the DEVICE's offset from UTC in minutes (IST = 330).
function localParts(instant, tzOffsetMin) {
  const d = new Date(new Date(instant).getTime() + tzOffsetMin * 60000);
  const p = n => String(n).padStart(2, '0');
  return { hour: d.getUTCHours(), minute: d.getUTCMinutes(), time: `${p(d.getUTCHours())}:${p(d.getUTCMinutes())}`,
           dayNumber: Math.floor(d.getTime() / 86400000) };
}
const slotForInstant = (instant, tzOffsetMin) => slotForHour(localParts(instant, tzOffsetMin).hour);
const daysAgoLabel = n => (n <= 0 ? 'today' : n === 1 ? 'yesterday' : `${n} days ago`);
const daysAgoBetween = (then, now, tz) => Math.max(0, localParts(now, tz).dayNumber - localParts(then, tz).dayNumber);

// --- Bands -------------------------------------------------------------------
const bandFor = s => (s >= 65 ? 'Safe' : s >= 45 ? 'Medium' : 'Risky');
const severityFor = s => ({ Safe: 'Low', Medium: 'Medium', Risky: 'High' })[bandFor(s)];

// --- Scores ------------------------------------------------------------------
// Base score per slot (area = row from the `areas` table):
//   morning   = locationScore + 8
//   afternoon = locationScore + 14
//   night     = locationScore - round(0.3 * nightRiskScore)
function baseScore(area, slot) {
  const loc = area.location_score;
  if (slot === 'morning') return clamp(loc + 8);
  if (slot === 'afternoon') return clamp(loc + 14);
  if (slot === 'night') return clamp(loc - roundHalfUp(0.3 * area.night_risk));
  throw new Error('Unknown slot: ' + slot);
}
// Live adjustment from recent USER reports in that slot (seed reports are already inside the base score).
// Problem reports: low -1, medium -2, high -3 (total capped at -10). "Felt safe": +1 each (capped at +5).
function liveAdjustment(userReports = []) {
  let neg = 0, pos = 0;
  for (const r of userReports) {
    if (r.category === 'felt_safe') pos += 1;
    else neg += { low: 1, medium: 2, high: 3 }[r.severity] || 0;
  }
  return Math.min(5, pos) - Math.min(10, neg);
}
function scoreFor(area, slot, userReports = []) {
  const base = baseScore(area, slot), adjustment = liveAdjustment(userReports), score = clamp(base + adjustment);
  return { slot, score, band: bandFor(score), severity: severityFor(score), base, adjustment };
}
const allSlotScores = (area, bySlot = {}) => Object.fromEntries(SLOT_NAMES.map(s => [s, scoreFor(area, s, bySlot[s] || [])]));
const breakdown = a => ({ theft: a.theft, nightSafety: a.night_safety, roadSafety: a.road_safety, womenSafety: a.women_safety });

// --- Geography ---------------------------------------------------------------
function haversineKm(lat1, lon1, lat2, lon2) {
  const r = x => (x * Math.PI) / 180, dLat = r(lat2 - lat1), dLon = r(lon2 - lon1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(r(lat1)) * Math.cos(r(lat2)) * Math.sin(dLon / 2) ** 2;
  return 12742 * Math.asin(Math.sqrt(a));
}
const rankByDistance = (areas, lat, lon) =>
  areas.map(a => ({ area: a, distanceKm: haversineKm(lat, lon, a.lat, a.lon) })).sort((x, y) => x.distanceKm - y.distanceKm);
function nearestArea(areas, lat, lon, maxKm = 25) {
  const n = rankByDistance(areas, lat, lon)[0];
  return n && n.distanceKm <= maxKm ? n : null;
}
module.exports = { SLOTS, SLOT_NAMES, slotForHour, slotForInstant, localParts, daysAgoLabel, daysAgoBetween, bandFor, severityFor,
  baseScore, liveAdjustment, scoreFor, allSlotScores, breakdown, haversineKm, rankByDistance, nearestArea };
