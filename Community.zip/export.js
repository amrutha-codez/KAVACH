// Writes data/reports.export.json = seed reports + every report users submitted, in the same shape as data/reports.json.
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { db } = require('./db');
const S = require('./scoring');
const slot = n => S.SLOTS.find(s => s.name === n);
const out = db.prepare('SELECT * FROM reports ORDER BY id').all().map(r => ({
  reportId: r.report_id || `USR${String(r.id).padStart(5, '0')}`, location: r.area, issueType: r.issue_type, timeSlot: r.time_slot,
  startHour: slot(r.time_slot).start, endHour: slot(r.time_slot).end, severity: r.severity, description: r.description, category: r.category,
  reportTime: r.source === 'user' ? S.localParts(r.submitted_at, r.tz_offset_min).time : r.report_time,
  ...(r.source === 'user' ? { submittedAt: r.submitted_at, tzOffsetMinutes: r.tz_offset_min } : { daysAgo: r.days_ago }),
  latitude: r.latitude, longitude: r.longitude, source: r.source }));
fs.writeFileSync(path.join(__dirname, '..', 'data', 'reports.export.json'), JSON.stringify(out, null, 2));
console.log(`Exported ${out.length} reports`);
